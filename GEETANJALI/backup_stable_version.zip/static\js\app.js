// ===================== MODE SELECTOR (Global Scope) =====================
function selectMode(mode) {
    const modeSelector = document.getElementById('mode-selector');
    const diseaseSection = document.getElementById('disease-mode-section');
    const chatSection = document.getElementById('chat-mode-section');

    // Fade out mode selector
    modeSelector.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
    modeSelector.style.opacity = '0';
    modeSelector.style.transform = 'scale(0.97)';

    setTimeout(() => {
        modeSelector.classList.add('hidden');
        modeSelector.style.opacity = '';
        modeSelector.style.transform = '';

        if (mode === 'disease') {
            diseaseSection.classList.remove('hidden');
            chatSection.classList.add('hidden');
        } else {
            chatSection.classList.remove('hidden');
            diseaseSection.classList.add('hidden');
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 380);
}

function goBack() {
    const modeSelector = document.getElementById('mode-selector');
    const diseaseSection = document.getElementById('disease-mode-section');
    const chatSection = document.getElementById('chat-mode-section');

    diseaseSection.classList.add('hidden');
    chatSection.classList.add('hidden');
    modeSelector.classList.remove('hidden');
    modeSelector.style.opacity = '0';
    modeSelector.style.transform = 'scale(0.97)';
    setTimeout(() => {
        modeSelector.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
        modeSelector.style.opacity = '1';
        modeSelector.style.transform = 'scale(1)';
    }, 50);
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function suggestQuestion(text) {
    const input = document.getElementById('crop-chat-input');
    if (input) { input.value = text; input.focus(); }
}

// ===================== CROP PLANNING CHATBOT =====================
document.addEventListener('DOMContentLoaded', () => {
    const cropChatInput = document.getElementById('crop-chat-input');
    const cropChatSendBtn = document.getElementById('crop-chat-send-btn');
    const cropChatMessages = document.getElementById('crop-chat-messages');
    const clearCropChatBtn = document.getElementById('clear-crop-chat');

    function addCropMsg(text, isUser) {
        const msg = document.createElement('div');
        if (isUser) {
            msg.className = 'user-crop-msg';
            msg.textContent = text;
        } else {
            msg.className = 'chat-msg crop-ai-msg';
            // Convert markdown-like text to readable HTML
            const formatted = text
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.*?)\*/g, '<em>$1</em>')
                .replace(/^- (.+)$/gm, '<li>$1</li>')
                .replace(/(<li>.*<\/li>)/gs, '<ul style="padding-left:20px;margin:8px 0">$1</ul>')
                .replace(/\n\n/g, '<br><br>')
                .replace(/\n/g, '<br>');
            msg.innerHTML = `<div class="chat-avatar-sm"><i class="fa-solid fa-robot"></i></div><div class="chat-bubble">${formatted}</div>`;
        }
        cropChatMessages.appendChild(msg);
        cropChatMessages.scrollTop = cropChatMessages.scrollHeight;
        return msg;
    }

    function addThinking() {
        const msg = document.createElement('div');
        msg.className = 'chat-msg crop-ai-msg';
        msg.id = 'thinking-indicator';
        msg.innerHTML = `<div class="chat-avatar-sm"><i class="fa-solid fa-robot"></i></div>
            <div class="chat-bubble thinking-dots"><span></span><span></span><span></span></div>`;
        cropChatMessages.appendChild(msg);
        cropChatMessages.scrollTop = cropChatMessages.scrollHeight;
        return msg;
    }

    async function sendCropMessage() {
        const message = cropChatInput?.value.trim();
        if (!message) return;
        cropChatInput.value = '';

        addCropMsg(message, true);
        const thinkingEl = addThinking();

        try {
            const res = await fetch('/crop-chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message })
            });
            const data = await res.json();
            thinkingEl.remove();
            addCropMsg(data.reply || 'Sorry, no response received.', false);
        } catch (e) {
            thinkingEl.remove();
            addCropMsg('Sorry, could not connect to AgriBot. Please check your internet connection.', false);
        }
    }

    cropChatSendBtn?.addEventListener('click', sendCropMessage);
    cropChatInput?.addEventListener('keydown', e => { if (e.key === 'Enter') sendCropMessage(); });

    clearCropChatBtn?.addEventListener('click', () => {
        if (cropChatMessages) {
            cropChatMessages.innerHTML = `
                <div class="chat-msg crop-ai-msg">
                    <div class="chat-avatar-sm"><i class="fa-solid fa-robot"></i></div>
                    <div class="chat-bubble">Chat cleared! Ask me anything about farming. 🌱</div>
                </div>`;
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {

    // ===================== DOM ELEMENTS =====================
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const defaultState = document.getElementById('default-state');
    const previewState = document.getElementById('preview-state');
    const imagePreview = document.getElementById('image-preview');
    const removeBtn = document.getElementById('remove-btn');
    const analyzeBtn = document.getElementById('analyze-btn');
    const loadingOverlay = document.getElementById('loading-overlay');
    const loadingStatusText = document.getElementById('loading-status-text');
    const resultsSection = document.getElementById('results-section');
    const featuresSection = document.getElementById('features-section');
    const scanNewBtn = document.getElementById('scan-new-btn');
    const historySection = document.getElementById('history-section');
    const historyList = document.getElementById('history-list');
    const chatInput = document.getElementById('chat-input');
    const chatSendBtn = document.getElementById('chat-send-btn');
    const chatMessages = document.getElementById('chatbot-messages');

    let currentFile = null;
    let lastResult = null; // Store last diagnosis for chatbot context
    let scanHistory = JSON.parse(localStorage.getItem('agrilens_history') || '[]');

    // ===================== THEME TOGGLE =====================
    const themeBtn = document.getElementById('theme-toggle-btn');
    const savedTheme = localStorage.getItem('agrilens_theme');
    if (savedTheme === 'light') document.body.classList.add('light-mode');
    if (themeBtn) {
        themeBtn.addEventListener('click', () => {
            document.body.classList.toggle('light-mode');
            const isLight = document.body.classList.contains('light-mode');
            localStorage.setItem('agrilens_theme', isLight ? 'light' : 'dark');
            themeBtn.innerHTML = isLight ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
        });
        themeBtn.innerHTML = savedTheme === 'light' ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
    }

    // ===================== DRAG AND DROP =====================
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(e => {
        dropZone.addEventListener(e, ev => { ev.preventDefault(); ev.stopPropagation(); }, false);
        document.body.addEventListener(e, ev => { ev.preventDefault(); ev.stopPropagation(); }, false);
    });
    ['dragenter', 'dragover'].forEach(e => dropZone.addEventListener(e, () => dropZone.classList.add('dragover'), false));
    ['dragleave', 'drop'].forEach(e => dropZone.addEventListener(e, () => dropZone.classList.remove('dragover'), false));
    dropZone.addEventListener('drop', e => handleFiles(e.dataTransfer.files), false);
    dropZone.addEventListener('click', () => { if (!currentFile) fileInput.click(); });
    fileInput.addEventListener('change', function () { if (this.files?.length > 0) handleFiles(this.files); });

    function handleFiles(files) {
        if (files.length > 0) {
            const file = files[0];
            if (!file.type.match('image.*')) { alert('Please upload an image file (JPG, PNG, WEBP)'); return; }
            if (file.size > 16 * 1024 * 1024) { alert('File is too large. Maximum size is 16MB.'); return; }
            currentFile = file;
            showPreview(file);
        }
    }

    function showPreview(file) {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onloadend = function () {
            imagePreview.src = reader.result;
            defaultState.classList.add('hidden');
            previewState.classList.remove('hidden');
            analyzeBtn.disabled = false;
        };
    }

    removeBtn.addEventListener('click', e => { e.stopPropagation(); resetUploadState(); });

    function resetUploadState() {
        currentFile = null; fileInput.value = '';
        imagePreview.src = '#';
        previewState.classList.add('hidden');
        defaultState.classList.remove('hidden');
        analyzeBtn.disabled = true;
    }

    scanNewBtn.addEventListener('click', () => {
        resultsSection.classList.add('hidden');
        featuresSection.classList.remove('hidden');
        resetUploadState();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // ===================== LOADING STATUS MESSAGES =====================
    const loadingMessages = [
        "Connecting to Google Gemini AI...",
        "Analyzing leaf textures and color patterns...",
        "Searching AI knowledge base for pathogens...",
        "Generating scientific diagnosis...",
        "Preparing chemical treatment recommendations..."
    ];
    let loadingMsgInterval;
    function startLoadingMessages() {
        let i = 0;
        if (loadingStatusText) loadingStatusText.textContent = loadingMessages[0];
        loadingMsgInterval = setInterval(() => {
            i = (i + 1) % loadingMessages.length;
            if (loadingStatusText) loadingStatusText.textContent = loadingMessages[i];
        }, 2000);
    }
    function stopLoadingMessages() { clearInterval(loadingMsgInterval); }

    // ===================== ANALYZE BUTTON =====================
    analyzeBtn.addEventListener('click', async () => {
        if (!currentFile) return;
        loadingOverlay.classList.remove('hidden');
        analyzeBtn.disabled = true;
        startLoadingMessages();

        const formData = new FormData();
        formData.append('file', currentFile);

        try {
            await new Promise(r => setTimeout(r, 1500)); // Small delay for realism
            const response = await fetch('/predict', { method: 'POST', body: formData });
            const data = await response.json();

            loadingOverlay.classList.add('hidden');
            stopLoadingMessages();

            if (data.success) {
                lastResult = data;
                // Apply current language before rendering
                renderResults(data);
                saveToHistory(data, currentFile);
            } else {
                alert(data.error || 'Analysis failed. Please try again.');
                resetUploadState();
            }
        } catch (error) {
            console.error('Error during analysis:', error);
            alert('A network error occurred. Please check your connection.');
            resetUploadState();
            loadingOverlay.classList.add('hidden');
            stopLoadingMessages();
        }
    });

    // ===================== RENDER RESULTS =====================
    function renderResults(data) {
        const details = data.disease_details;
        featuresSection.classList.add('hidden');
        resultsSection.classList.remove('hidden');

        document.getElementById('result-image').src = data.image_url;
        document.getElementById('conf-value').textContent = data.confidence + '%';
        document.getElementById('crop-tag').textContent = details.crop || 'Unknown';
        document.getElementById('disease-name').textContent = data.prediction;
        document.getElementById('scientific-name').textContent = details.scientific_name ? `(${details.scientific_name})` : '';
        document.getElementById('symptoms-text').textContent = details.symptoms;
        document.getElementById('causes-text').textContent = details.causes;
        document.getElementById('treatment-text').textContent = details.treatment;
        document.getElementById('prevention-text').textContent = details.prevention;

        // Chemicals List
        const chemList = document.getElementById('chemicals-list');
        chemList.innerHTML = '';
        if (details.recommended_chemicals?.length > 0) {
            details.recommended_chemicals.forEach(c => {
                const li = document.createElement('li'); li.textContent = c; chemList.appendChild(li);
            });
        } else {
            chemList.innerHTML = '<li>No chemical treatment recommended.</li>';
        }

        // Severity badge + Card Glow
        const badge = document.getElementById('severity-badge');
        badge.textContent = (details.severity || 'Unknown') + ' Severity';
        badge.className = 'severity-badge';
        const dataCard = document.getElementById('data-card');
        dataCard.className = 'result-card data-card'; // Reset glow
        const sevLower = (details.severity || '').toLowerCase();
        if (sevLower.includes('critical')) { badge.classList.add('sev-critical'); dataCard.classList.add('glow-critical'); }
        else if (sevLower.includes('high')) { badge.classList.add('sev-high'); dataCard.classList.add('glow-high'); }
        else if (sevLower.includes('medium')) { badge.classList.add('sev-medium'); dataCard.classList.add('glow-medium'); }
        else if (sevLower.includes('low')) { badge.classList.add('sev-low'); dataCard.classList.add('glow-low'); }
        else { badge.classList.add('sev-none'); dataCard.classList.add('glow-none'); }

        // Confidence Bar Animation
        const confBar = document.getElementById('conf-bar');
        confBar.style.width = '0%';
        setTimeout(() => { confBar.style.width = data.confidence + '%'; }, 300);

        // Plant Health Score
        let healthScore = Math.round(data.confidence);
        if (sevLower.includes('critical')) healthScore = Math.round(healthScore * 0.2);
        else if (sevLower.includes('high')) healthScore = Math.round(healthScore * 0.4);
        else if (sevLower.includes('medium')) healthScore = Math.round(healthScore * 0.6);
        else if (sevLower.includes('low')) healthScore = Math.round(healthScore * 0.8);
        document.getElementById('health-score').textContent = Math.min(healthScore, 99);

        // Reset Chatbot
        chatMessages.innerHTML = `
            <div class="chat-msg ai-msg">
                <i class="fa-solid fa-leaf"></i>
                I've diagnosed your plant as having <strong>${data.prediction}</strong> on a ${details.crop || 'Unknown'} leaf. 
                Ask me any follow-up questions!
            </div>`;

        // Scroll to results
        setTimeout(() => resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    }

    // ===================== LANGUAGE SELECTOR =====================
    langSelector?.addEventListener('change', async () => {
        if (!lastResult) return;
        const lang = langSelector.value;
        if (lang === 'en') { renderResults(lastResult); return; }

        const langNames = { te: 'Telugu' }; // Only Telugu supported now
        const targetLang = langNames[lang];

        try {
            // Get original English text from lastResult to ensure accurate translation every time
            const d = lastResult.disease_details;
            const textsToTranslate = {
                symptoms: d.symptoms,
                causes: d.causes,
                treatment: d.treatment,
                prevention: d.prevention
            };

            const response = await fetch('/translate', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    texts: textsToTranslate,
                    target_lang: targetLang
                })
            });
            const data = await response.json();
            if (data.success) {
                try {
                    const t = data.translations;
                    if (t.symptoms) document.getElementById('symptoms-text').textContent = t.symptoms;
                    if (t.causes) document.getElementById('causes-text').textContent = t.causes;
                    if (t.treatment) document.getElementById('treatment-text').textContent = t.treatment;
                    if (t.prevention) document.getElementById('prevention-text').textContent = t.prevention;
                } catch (e) { console.warn('Translation render error', e); }
            } else {
                console.error('Translation failed from server:', data.error);
            }
        } catch (e) { console.error('Translation network error', e); }
    });

    // ===================== VOICE OUTPUT =====================
    document.getElementById('voice-btn')?.addEventListener('click', () => {
        if (!lastResult) return;
        const synth = window.speechSynthesis;
        if (synth.speaking) { synth.cancel(); return; }
        const details = lastResult.disease_details;
        const text = `Your ${details.crop} plant was diagnosed with ${lastResult.prediction}. Confidence: ${lastResult.confidence} percent. Symptoms: ${details.symptoms}. Treatment: ${details.treatment}`;
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.9;
        synth.speak(utterance);
    });

    // ===================== WHATSAPP SHARE =====================
    document.getElementById('whatsapp-btn')?.addEventListener('click', () => {
        if (!lastResult) return;
        const d = lastResult.disease_details;
        const msg = `🌱 *AgriLens Crop Report*\n\n*Crop:* ${d.crop}\n*Diagnosis:* ${lastResult.prediction}\n*Confidence:* ${lastResult.confidence}%\n*Severity:* ${d.severity}\n\n*Symptoms:* ${d.symptoms}\n\n*Treatment:* ${d.treatment}\n\n_Scanned using AgriLens AI_`;
        const url = `https://wa.me/?text=${encodeURIComponent(msg)}`;
        window.open(url, '_blank');
    });

    // ===================== PDF DOWNLOAD =====================
    document.getElementById('pdf-btn')?.addEventListener('click', () => {
        if (!lastResult || !window.jspdf) { alert('PDF library not loaded yet. Please wait a moment.'); return; }
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const d = lastResult.disease_details;
        const margin = 15; let y = 20;

        doc.setFontSize(22); doc.setTextColor(12, 165, 84);
        doc.text('AgriLens - Crop Disease Report', margin, y); y += 12;
        doc.setFontSize(10); doc.setTextColor(120, 120, 120);
        doc.text(`Generated: ${new Date().toLocaleString()}`, margin, y); y += 14;

        doc.setDrawColor(12, 165, 84); doc.line(margin, y, 195, y); y += 10;

        const addSection = (title, text) => {
            doc.setFontSize(13); doc.setTextColor(40, 40, 40);
            doc.text(title, margin, y); y += 8;
            doc.setFontSize(10); doc.setTextColor(70, 70, 70);
            const lines = doc.splitTextToSize(text || 'N/A', 175);
            doc.text(lines, margin, y); y += lines.length * 6 + 8;
            if (y > 270) { doc.addPage(); y = 20; }
        };

        addSection('Crop:', d.crop || 'Unknown');
        addSection('Disease Detected:', lastResult.prediction);
        addSection('Scientific Name:', d.scientific_name || 'N/A');
        addSection('Confidence Score:', lastResult.confidence + '%');
        addSection('Severity:', d.severity || 'N/A');
        addSection('Symptoms:', d.symptoms);
        addSection('Causes:', d.causes);
        addSection('Treatment:', d.treatment);
        addSection('Prevention:', d.prevention);
        addSection('Recommended Chemicals:', (d.recommended_chemicals || []).join(', '));

        doc.save(`AgriLens_Report_${lastResult.prediction.replace(/ /g, '_')}.pdf`);
    });

    // ===================== CHATBOT =====================
    function buildContext(data) {
        const d = data.disease_details;
        return `Crop: ${d.crop}, Disease: ${data.prediction}, Confidence: ${data.confidence}%, Severity: ${d.severity}, Symptoms: ${d.symptoms}, Treatment: ${d.treatment}`;
    }

    async function sendChatMessage() {
        const question = chatInput.value.trim();
        if (!question || !lastResult) return;
        chatInput.value = '';

        const userMsg = document.createElement('div');
        userMsg.className = 'chat-msg user-msg';
        userMsg.textContent = question;
        chatMessages.appendChild(userMsg);

        const thinkingMsg = document.createElement('div');
        thinkingMsg.className = 'chat-msg ai-msg thinking-dots';
        thinkingMsg.innerHTML = '<i class="fa-solid fa-leaf"></i><span></span><span></span><span></span>';
        chatMessages.appendChild(thinkingMsg);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        try {
            const res = await fetch('/chat', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ question, context: buildContext(lastResult) })
            });
            const data = await res.json();
            chatMessages.removeChild(thinkingMsg);
            const aiMsg = document.createElement('div');
            aiMsg.className = 'chat-msg ai-msg';
            aiMsg.innerHTML = '<i class="fa-solid fa-leaf"></i>' + (data.reply || 'No response.');
            chatMessages.appendChild(aiMsg);
        } catch (e) {
            chatMessages.removeChild(thinkingMsg);
            const errMsg = document.createElement('div');
            errMsg.className = 'chat-msg ai-msg';
            errMsg.innerHTML = '<i class="fa-solid fa-leaf"></i>Sorry, could not connect to AI.';
            chatMessages.appendChild(errMsg);
        }
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    chatSendBtn?.addEventListener('click', sendChatMessage);
    chatInput?.addEventListener('keydown', e => { if (e.key === 'Enter') sendChatMessage(); });

    // ===================== SCAN HISTORY =====================
    function saveToHistory(data, file) {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onloadend = () => {
            const entry = {
                imageDataUrl: reader.result,
                prediction: data.prediction,
                crop: data.disease_details?.crop || 'Unknown',
                confidence: data.confidence,
                timestamp: Date.now()
            };
            scanHistory.unshift(entry);
            if (scanHistory.length > 5) scanHistory.pop();
            localStorage.setItem('agrilens_history', JSON.stringify(scanHistory));
            renderHistory();
        };
    }

    function renderHistory() {
        if (scanHistory.length === 0) return;
        historySection.style.display = 'block';
        historyList.innerHTML = '';
        scanHistory.forEach(entry => {
            const item = document.createElement('div');
            item.className = 'history-item';
            item.innerHTML = `
                <img src="${entry.imageDataUrl}" alt="${entry.prediction}" loading="lazy">
                <div class="history-label">${entry.prediction}</div>
            `;
            historyList.appendChild(item);
        });
    }

    renderHistory(); // Render any existing history on page load
});
