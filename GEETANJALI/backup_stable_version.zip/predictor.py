import os
import time
import json
from PIL import Image
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")

def analyze_image(image_path, retries=5):
    """
    Analyzes the image using Gemini 1.5 Flash with robust auto-retry logic for 503 errors.
    Dynamically generates the diagnosis, symptoms, and chemical treatments from the AI's internal knowledge base.
    """
    if not api_key:
        return {"success": False, "error": "Gemini API Key missing. Check .env file."}
        
    client = genai.Client(api_key=api_key)
    
    try:
        img = Image.open(image_path)
    except Exception as e:
        return {"success": False, "error": f"Failed to open image file: {str(e)}"}
        
    prompt = """
    You are an expert AI agricultural plant pathologist. Analyze this image of a plant or leaf.
    Identify the exact crop and any disease present. If the plant is completely healthy, state that it is Healthy.
    
    CRITICAL INSTRUCTION: You MUST dynamically generate a comprehensive scientific response containing 
    the symptoms, causes, treatments, prevention strategies, and specific recommended chemicals for this specific disease.
    
    You MUST return ONLY a raw JSON object string with the following exact schema, no markdown blocks, no other text:
    {
        "detected_crop": "Name of the crop (e.g., Tomato, Rice, Cotton)",
        "prediction": "Specific name of the disease (e.g., Early Blight), OR 'Healthy'",
        "confidence": A number from 0.0 to 99.9 representing your certainty,
        "disease_details": {
            "scientific_name": "Scientific name of the pathogen, or N/A",
            "symptoms": "Detailed paragraph describing visual symptoms on the leaf",
            "causes": "Detailed paragraph describing environmental or biological causes",
            "severity": "Low, Medium, High, or None",
            "treatment": "Detailed paragraph describing non-chemical treatments and actions",
            "prevention": "Detailed paragraph describing how to prevent this in the future",
            "affected_parts": ["Leaves", "Stems", "Roots", etc as a list of strings],
            "recommended_chemicals": ["Specific Chemical 1", "Specific Chemical 2", etc as a list of strings]
        }
    }
    """
    
    last_error = ""
    # Auto-retry loop to handle 503 Service Unavailable / High Demand errors seamlessly
    for attempt in range(retries):
        try:
            print(f"\n--- Calling Gemini AI (Attempt {attempt+1}/{retries}) ---")
            response = client.models.generate_content(
                model='gemini-2.5-flash',
                contents=[prompt, img],
                config=types.GenerateContentConfig(
                    temperature=0.1, # Low temperature for factual precision
                ),
            )
            
            response_text = response.text.strip()
            
            # Clean up JSON if Gemini wraps it in markdown blocks
            if response_text.startswith("```json"):
                response_text = response_text[7:-3].strip()
            elif response_text.startswith("```"):
                response_text = response_text[3:-3].strip()
                
            ai_data = json.loads(response_text)
            
            print("--- GEMINI AI DYNAMIC JSON LOADED SUCCESSFULLY ---")
            
            # Validate response schema
            if "disease_details" not in ai_data:
                raise ValueError("JSON response missing the requested 'disease_details' dictionary.")
                
            return {
                "success": True,
                "detected_crop": ai_data.get("detected_crop", "Unknown"),
                "prediction": ai_data.get("prediction", "Unknown Disease"),
                "confidence": ai_data.get("confidence", 95.0),
                "disease_details": ai_data["disease_details"]
            }
            
        except Exception as e:
            error_str = str(e)
            print(f"Gemini API Error (Attempt {attempt+1}): {error_str}")
            last_error = error_str
            
            # If the error is high demand (503), use Exponential Backoff
            if "503" in error_str or "UNAVAILABLE" in error_str or "overloaded" in error_str.lower():
                sleep_time = 2 ** attempt  # 1s, 2s, 4s, 8s, 16s...
                print(f"High demand detected from Google API. Retrying automatically in {sleep_time} seconds to ensure demo success...")
                time.sleep(sleep_time)
            else:
                # For JSON parsing errors or other glitches, retry immediately
                time.sleep(1)
                
    # If all loops fail
    return {
        "success": False,
        "error": f"Failed after {retries} automatic attempts to bypass API load. Last error: {last_error}"
    }
